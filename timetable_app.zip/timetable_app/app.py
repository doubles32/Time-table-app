import json
from pathlib import Path
from datetime import datetime

import pandas as pd
import streamlit as st

st.set_page_config(page_title="시간표 앱", page_icon="📚", layout="wide")

DATA_DIR = Path(__file__).parent
DATA_FILE = DATA_DIR / "timetable_data.json"
DAYS = ["월", "화", "수", "목", "금", "토", "일"]
TIME_SLOTS = [
    "07:00", "08:00", "09:00", "10:00", "11:00", "12:00",
    "13:00", "14:00", "15:00", "16:00", "17:00", "18:00",
    "19:00", "20:00", "21:00"
]


def default_data():
    return {
        "owner": "지안",
        "schedule": {day: {slot: "" for slot in TIME_SLOTS} for day in DAYS},
        "updated_at": None,
    }


def load_data():
    if DATA_FILE.exists():
        try:
            return json.loads(DATA_FILE.read_text(encoding="utf-8"))
        except Exception:
            return default_data()
    return default_data()


def save_data(data):
    data["updated_at"] = datetime.now().strftime("%Y-%m-%d %H:%M")
    DATA_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def build_dataframe(data):
    rows = []
    for slot in TIME_SLOTS:
        row = {"시간": slot}
        for day in DAYS:
            row[day] = data["schedule"][day].get(slot, "")
        rows.append(row)
    return pd.DataFrame(rows)


if "data" not in st.session_state:
    st.session_state.data = load_data()

st.title("📚 간단한 시간표 앱")
st.caption("아이폰·아이패드에서 브라우저로 열어 쓸 수 있는 Streamlit 앱입니다.")

with st.sidebar:
    st.subheader("기본 설정")
    owner = st.text_input("이름", value=st.session_state.data.get("owner", "지안"))
    st.session_state.data["owner"] = owner
    st.write("마지막 저장:", st.session_state.data.get("updated_at") or "아직 없음")
    if st.button("예시 시간표 넣기"):
        demo = default_data()
        demo["owner"] = owner
        demo["schedule"]["월"]["09:00"] = "학교"
        demo["schedule"]["월"]["16:00"] = "영어"
        demo["schedule"]["화"]["16:00"] = "태권도"
        demo["schedule"]["수"]["15:00"] = "피아노"
        demo["schedule"]["목"]["16:00"] = "수학"
        demo["schedule"]["금"]["15:00"] = "미술"
        demo["schedule"]["토"]["10:00"] = "수영"
        st.session_state.data = demo
        st.success("예시 시간표를 불러왔습니다.")
    if st.button("전체 초기화"):
        st.session_state.data = default_data()
        st.session_state.data["owner"] = owner
        st.warning("시간표를 초기화했습니다.")

st.markdown(f"### {st.session_state.data['owner']} 시간표")

tab1, tab2 = st.tabs(["편집", "보기"])

with tab1:
    st.info("칸을 비워두면 해당 시간은 일정이 없는 것으로 표시됩니다.")
    for day in DAYS:
        with st.expander(f"{day}요일", expanded=(day in ["월", "화", "수", "목", "금"])):
            for slot in TIME_SLOTS:
                key = f"{day}_{slot}"
                current = st.session_state.data["schedule"][day].get(slot, "")
                value = st.text_input(f"{slot} · {day}", value=current, key=key, placeholder="예: 학교 / 영어 / 수영")
                st.session_state.data["schedule"][day][slot] = value.strip()

    c1, c2 = st.columns(2)
    with c1:
        if st.button("저장하기", use_container_width=True):
            save_data(st.session_state.data)
            st.success("저장되었습니다.")
    with c2:
        if st.button("CSV 내려받기 준비", use_container_width=True):
            st.success("아래 보기 탭에서 CSV 다운로드를 사용할 수 있습니다.")

with tab2:
    df = build_dataframe(st.session_state.data)
    st.dataframe(df, use_container_width=True, hide_index=True)

    csv = df.to_csv(index=False).encode("utf-8-sig")
    st.download_button(
        label="CSV 다운로드",
        data=csv,
        file_name=f"{st.session_state.data['owner']}_시간표.csv",
        mime="text/csv",
        use_container_width=True,
    )

    today_idx = datetime.today().weekday()
    if today_idx < 7:
        today = DAYS[today_idx]
        today_items = [
            (slot, st.session_state.data["schedule"][today][slot])
            for slot in TIME_SLOTS
            if st.session_state.data["schedule"][today][slot]
        ]
        st.markdown(f"#### 오늘({today}요일) 일정")
        if today_items:
            for slot, item in today_items:
                st.write(f"- {slot} · {item}")
        else:
            st.write("등록된 일정이 없습니다.")

st.divider()
st.markdown(
    "**실행 방법**  \n"
    "1. `pip install -r requirements.txt`  \n"
    "2. `streamlit run app.py`  \n"
    "3. 아이폰/아이패드에서 같은 네트워크로 접속하거나 Streamlit Cloud에 배포해서 사용"
)
