# 간단한 시간표 앱

아이폰/아이패드/맥/윈도우에서 브라우저로 사용할 수 있는 Streamlit 기반 시간표 앱입니다.

## 실행

```bash
pip install -r requirements.txt
streamlit run app.py
```

## 기능
- 요일별/시간별 일정 입력
- 로컬 JSON 저장
- CSV 다운로드
- 오늘 일정 표시
- 예시 시간표 자동 입력

## 배포
- Streamlit Community Cloud에 올리면 외부에서도 접속 가능
- 같은 Wi-Fi 환경에서는 로컬 실행 후 아이폰/아이패드 브라우저로 접속 가능
